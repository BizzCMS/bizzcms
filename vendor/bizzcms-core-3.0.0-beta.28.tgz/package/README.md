# bizzcms-core

The CMS engine behind [BizzCMS](https://bizzcms.com). Use it through the BizzCMS repository: https://github.com/BizzCMS/bizzcms

Licence: MIT (see LICENSE).
